# Paquetes necesarios
install.packages("blogdown")
install.packages("rmarkdown")
install.packages("xtable")
install.packages("sourcetools")
install.packages("shiny")
install.packages("miniUI")
install.packages("rstudioapi")
install.packages("ggplot2")

blogdown::install_hugo(force = TRUE)

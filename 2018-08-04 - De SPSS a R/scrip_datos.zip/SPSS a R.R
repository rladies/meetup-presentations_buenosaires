#####################################################
######### SPSS a R: Nociones b�sicas ################
#####################################################

# Crear objetos:

# 1. Vector: Usar c() para concatenar elementos.

c(1,4,6,3,9)

Vector1<-c(1,4,6,3,9)

Vector2<-c(1:200) # crea secuencia de 1 a 200

Vector2<-as.numeric(Vector2) 
# si al nuevo objeto se lo llama de igual forma que al anterior,
# se escribe sobre el anteior. 

Vector3<-c("Juana", "Laura", "Silvia", "Ana", "Julia")

Vector3[3] # acceso a los componentes de un vector

#2. Data frame:

Base<-data.frame(Vector1, Vector3)

View(Base)

summary(Base) # Descriptivos generales de las variables

# Borrar todo lo almacenado.
rm(list = ls())

###########################################
#### Importar una base desde el script ####

# Setear el working directory (carpeta en la que est�n las bases y archivos
# para realizar los an�lisis).

setwd("C:/Users/Jesi/Desktop/RLadies")

# Importar la base: depende del tipo de archivo.

# Archivo de excel

library(readxl)

Comp <- read_excel("Comptxt.xlsx")

View(Comp)

# Valores separados por coma (cvs)

Comp1<-read.csv("Comptxt.csv", sep = ";", dec = ",") 
# Sep = operador que separa los valores (usualmente "," o ";")
# dec = operador que indica decimales (usualmente "," o ".")

# Archivo de texto (*.txt)

Comp2<-read.table("Comptxt.txt", sep = "\t") # \t = tabulaci�n
View(Comp2)

Comp2<-read.table("Comptxt.txt", sep = "\t", header = TRUE)
View(Comp2)
# header = TRUE toma la primer l�nea como nombre de las variables 

# Eliminar un objeto

rm(Comp1)
rm(Comp2)

##### Coordenadas dentro del data frame #######3

# Seleccionar una variable: $

Comp$ID

### Ejercicio 1. 
# Selecciona la variable memoria. Luego de $ se listas las variables


# Seleccionar una variable por el n�mero de columna

Comp[,1]

# Seleccionar todas las observaciones de una misma fila

Comp[3,]

# Seleccionar un �nico valor de la fila 4, y la columna 3

Comp[4,3]

# Seleccionar las columnas 1 y 4

Comp[,c(1,4)] # Record� que c() permite concatenar, unir

# Esta funci�n devuelve las posiciones de los valores mayores a 15.
which(Comp$Memoria>15)

# Con esta funci�n podemos ver cuales son esos valores
Comp$Memoria[which(Comp$Memoria>15)]

# Seleccionar valores de un variable condicional a otra
Comp$Memoria[Comp$Sexo==1]

### Ejercicio 2:
# Seleccionar las columnas 1,2 y 3 y asignarlas a un nuevo objeto "Comp_1"



### Ejercicio 3:
# Crear un data frame nuevo con las variables ID, Memoria y Comp
# y asignalo a un objeto nuevo de nombre "Comp_2"
# Record� los comandos:
# Base<-data.frame(Vector1, Vector3)
# Comp$ID
# o Comp[,1]


# Cambiar el nombre de las variables de Comp_2

names(Comp_2)<-c("ID", "Memoria", "Comprension") 
# Record� que las palabras van entre comillas"

# Eliminar los objetos Comp_1 y Comp_2

rm(Comp_1, Comp_2)

# Explorar la base

summary(Comp) # Observ� que se obtienen los descriptivos de Sexo e ID.

# convertir la variable Sexo en factor

Comp$Sexo<-as.factor(Comp$Sexo)

# Volver a pedir descriptivos

summary(Comp) # Al ser factor se registra la frecuencia

# Pedir descriptivos espec�ficos

mean(Comp$Memoria) # Media
sd(Comp$Memoria) # Desv�o Estandar

# Frecuencias

table(Comp$Edad, Comp$Sexo) # % de ni�os de cada edad y cada sexo.

prop.table(table(Comp$Edad, Comp$Sexo), margin = 1) # prop sexo seg�n edad

# Descriptivos por sexo:

library(psych)

describeBy(Comp, group = Comp$Sexo) # Data frame, variable de agrupaci�n

describeBy(Comp[,-c(1,3)], group = Comp$Sexo) # No pido descriptivos
# para sexo o ID. Resto esas columnas. Uso c() porque son m�s de una.


# Aggregate permite aplicar funciones (en este caso mean() y sd())
# a todas las columnas de un df. 

Comp_desc <- aggregate(. ~ Edad, Comp, function(x) c(mean = mean(x), sd = sd(x)))

# El resultado es un df (Comp_desc) donde cada columna es un df en si
# mismo, que contiene la media y el desv�o de cada variable. 
# Para desagregarlo usamos el comando do.call

Comp_desc<-do.call("data.frame", Comp_desc)


#########################
### Modificar la base ###

# Recodificar la variable Comp en "Bajo" en valores menores a la media
# y "Altos" en valores mayores a la media, y asignarlo a una nueva var
# Comp2.

mean(Comp$Comp) # Obtengo la media
Comp$Comp2[Comp$Comp > 18] <- "Bajo" # Indico condici�n y asigno nuevo valor
Comp$Comp2[Comp$Comp <= 18] <- "Alto"

# Otra forma de recodificar una variable num�rica como categ�rica
# y asignarla a una nueva variable (Comp3)
Comp$Comp3 <- cut(Comp$Comp, breaks=c(-Inf, mean(Comp$Comp), Inf), labels=c("Bajo","Alto"))

# Eliminar una fila espec�fica
Comp<-Comp[-8,]

# Eliminar una fila seg�n alguna condici�n
Comp<-Comp[!(Comp$Memoria==27 & Comp$Comp3=="Bajo"),]

# Elimar una columna
Comp<-Comp[,-8]

# Otra forma de eliminar una columna
Comp$Comp3<-NULL

# Subset: obtener un nuevo df seleccionando casos en base a una variable
Comp_10a<-subset(Comp, Edad==10) 
# Comp_10a es el df Comp, pero solo para los casos en que la var Edad es = a 10.

Comp_14a<-subset(Comp, Edad==14)

# Unir dos data frames con columnas iguales
Comp4<-rbind(Comp_10a, Comp_14a) # rbind = Row Bind (Unir filas)
# Si fueran mismos sujetos pero m�s columnas usariamos "cbind"

rm(list = ls()) # Borramos todo lo hecho hasta el momento.

### Ejercicio 4: 
# Importar base de datos "Trat.csv". Llamar "Trat" al df.


# Modificar de wide a long. Los tratamientos A, B y C pasan a ser
# categor�as de una nueva variable, y los valores una �nica variable. 
# Es necesario para realizar varios tipos de an�lisis (ej. ANOVA)

library(reshape2)

TratL <- melt(Trat, variable.name = "Tratamiento", value.name = "Valor")

# El ejemplo de ANOVA

Modelo1<-lm(Valor~Tratamiento, data = TratL)
anova(Modelo1)

### Ejercicio 5: Pedir descriptivos de la base

### Ejercicio 6: Pedir descriptivos por tratamiento


# Separar el data frame en varios seg�n condici�n tratamiento:

a<-split(TratL, TratL$Tratamiento) #Crea una lista con 3 df, uno por tratamiento.

# Obtener el Df del tratamiento A. 

a$Trat_A 

a[[1]] # Otra forma de obtener un elemento de una lista

rm(list = ls())

###########################################################
###### Algunas de las cosas que podemos hacer #############

### Ejercicio 7: Import� el archivo Comptxt.csv. (record� incluir
# header = TRUE)


# Hay una relaci�n lineal entre Memoria y Comp (comprensi�n de texto)?

plot(Comp$Atencion, Comp$Comp)
plot(Comp$Memoria, Comp$Comp)
plot(Comp$Vocabulario, Comp$Comp)

# Plantear un modelo de regresi�n con Atencion como predictora
# y Comp (comprensi�n de texto) como variable respuesta.

Ajuste<-lm(Comp~Atencion+Memoria+Vocabulario, data = Comp)
summary(Ajuste)

# Sj para correlaciones, crear tablas, 

#Correlaciones con una tabla que se guarda en word.

library(sjPlot)
sjt.corr(Comp[,-c(1:3)],
         title = "Tabla 2. Correlaciones",
         fade.ns = FALSE,
         p.numeric = TRUE,
         triangle = "upper",
         file="Correlaciones.doc")

# Gr�ficos diagn�sticos
p<-plot_model(Ajuste, type = "diag")
plot_grid(p, margin = c(0.2, 0.2, 0.2, 0.2)) # Para que se presenten juntos

# Estad�sticos diagn�sticos:
# Ajuste es una objeto LISTA. Podemos obtener los residuos del modelo
# y evaluar si son normales

res<-resid(Ajuste)
shapiro.test(res)

res2<-Ajuste$residuals
shapiro.test(res2)

res3<-Ajuste[[2]]
shapiro.test(res3)

# Graficar los coeficientes:
plot_model(Ajuste, type = "est", show.values= TRUE, show.p = TRUE, vline.color = "blue")
